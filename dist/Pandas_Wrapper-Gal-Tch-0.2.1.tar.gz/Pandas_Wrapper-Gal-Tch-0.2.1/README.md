# Pandas_Wrapper

# Description:
Our package is wrapping the "pandas" package, the package is updating the user whenever a new dataFrame is created and how long it took
for the program to create the dataFrame. the program can also display a gui that shows the used dataFrame.

# Installation:
use the command : 

pip install -i https://test.pypi.org/simple/ Pandas-Wrapper-Gal-Tch

to install the Pandas_wrapper package.
our package uses "pandas", "numpy" and "eel" packages that will be installed automatically.

# License:
